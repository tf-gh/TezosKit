// Copyright Keefer Taylor, 2018

import TezosKit
import XCTest

// swiftlint:disable force_cast

class TransactionOperationTest: XCTestCase {
  public func testTransation() {
    let balance = Tez(3.50)
    guard case let .success(operation) = OperationFactory.testFactory.transactionOperation(
      amount: balance,
      source: .testAddress,
      destination: .testDestinationAddress,
      operationFeePolicy: .default,
      signatureProvider: FakeSignatureProvider.testSignatureProvider
    ) else {
      XCTFail()
      return
    }
    let dictionary = operation.dictionaryRepresentation

    XCTAssertNotNil(dictionary["source"])
    XCTAssertEqual(dictionary["source"] as? String, .testAddress)

    XCTAssertNotNil(dictionary["destination"])
    XCTAssertEqual(dictionary["destination"] as? String, .testDestinationAddress)

    XCTAssertNotNil(dictionary["amount"])
    XCTAssertEqual(dictionary["amount"] as? String, balance.rpcRepresentation)
  }
}
