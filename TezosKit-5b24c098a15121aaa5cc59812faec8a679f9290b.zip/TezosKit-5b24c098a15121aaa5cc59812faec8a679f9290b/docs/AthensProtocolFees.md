# Fees for Athens Protocol (Protocol 004)

Nomadic Labs (Athens protocol developers) has published operation fees here: http://tezos.gitlab.io/master/protocols/004_Pt24m4xi.html.

The history for this file contains my previous recommended values.
