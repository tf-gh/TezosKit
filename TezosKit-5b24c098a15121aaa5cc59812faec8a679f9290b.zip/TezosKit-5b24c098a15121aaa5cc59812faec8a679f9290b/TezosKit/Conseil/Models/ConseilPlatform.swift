// Copyright Keefer Taylor, 2019.

/// Platforms supported by Conseil.
public enum ConseilPlatform: String, CaseIterable {
  case tezos
}
