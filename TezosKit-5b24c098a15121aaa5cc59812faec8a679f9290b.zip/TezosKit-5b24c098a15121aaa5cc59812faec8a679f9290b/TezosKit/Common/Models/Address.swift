// Copyright Keefer Taylor, 2019.

import Foundation

public typealias Address = String
